extends Panel

@onready var item: TextureRect = $item

func _get_drag_data(_at_position: Vector2) -> Variant:
	if item.texture == null:
		return
	
	var preview = duplicate()
	var c = Control.new()
	c.add_child(preview)
	preview.position -= Vector2(25,25)
	preview.self_modulate = Color.TRANSPARENT
	c.modulate = Color(c.modulate,0.5)
	set_drag_preview(c)
	return item
	
func _can_drop_data(_at_position: Vector2, _data: Variant) -> bool:
	return true
	
func _drop_data(_at_position: Vector2, data: Variant) -> void:
	var top = item.texture
	item.texture = data.texture
	data.texture = null
	data.texture = top
