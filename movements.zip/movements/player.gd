extends CharacterBody2D

@onready var animation: AnimatedSprite2D = $AnimatedSprite2D

var speed := 100
var direction := Vector2()

func _physics_process(delta: float):
	direction = Input.get_vector("left","right","up","down")
	velocity = speed * direction * delta
	position += velocity
	
	if direction.x > 0:
		animation.flip_h = false
		animation.play("sides")
	elif direction.x < 0:
		animation.flip_h = true
		animation.play("sides")
	elif direction.y > 0:
		animation.play("down")
	elif direction.y < 0:
		animation.play("up")
	else:
		animation.frame = 0


	move_and_slide()
