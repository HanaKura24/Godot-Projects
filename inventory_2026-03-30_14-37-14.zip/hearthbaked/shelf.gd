extends Panel

func _can_drop_data(_at_position: Vector2, _data: Variant) -> bool:
	return true

func _notification(what: int) -> void:
	var data_bk 
	if what == Node.NOTIFICATION_DRAG_BEGIN:
		data_bk = get_viewport().gui_get_drag_data()
	if what == Node.NOTIFICATION_DRAG_END:
		if not is_drag_successful():
			if data_bk:
				data_bk.show()
				data_bk = null
	
